import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { mlAPI } from '../api/client';
import { useNotificationStore } from '../store';
import {
  Brain,
  RefreshCw,
  Activity,
  Target,
  Crosshair,
  Zap,
  BarChart3,
  Layers,
} from 'lucide-react';
import EmptyState from '../components/common/EmptyState';
import ErrorState from '../components/common/ErrorState';
import { SkeletonBox, ChartSkeleton } from '../components/common/Skeleton';
import {
  toPersianDigits,
  formatNumber,
  formatPercent,
  formatDateTime,
} from '../utils/formatters';

const STATUS_MAP = {
  active: { text: 'فعال', class: 'badge-green' },
  training: { text: 'در حال آموزش', class: 'badge-blue' },
  untrained: { text: 'آموزش‌ندیده', class: 'bg-yellow-500/15 text-yellow-500' },
  error: { text: 'خطا', class: 'badge-red' },
  inactive: { text: 'غیرفعال', class: 'bg-surface-elevated text-text-muted' },
};

// نمایشِ صادقانهٔ متریک: مقادیرِ اندازه‌گیری‌نشده (۰) به‌صورت «—» نمایش داده می‌شوند
function metricDisplay(value) {
  const num = typeof value === 'number' ? value : parseFloat(value);
  if (!Number.isFinite(num) || num <= 0) return '—';
  return formatPercent(num);
}

function ModelCard({ model, onRetrain, isRetraining }) {
  const st = STATUS_MAP[model.status] || STATUS_MAP.inactive;
  const isTraining = model.status === 'training';

  const lastTrained = model.lastTrained ? formatDateTime(model.lastTrained) : '—';
  const dataPoints =
    model.dataPoints > 0 ? toPersianDigits(formatNumber(model.dataPoints)) : '—';
  const duration =
    model.trainingDuration && model.trainingDuration !== '—'
      ? toPersianDigits(model.trainingDuration)
      : '—';

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-brand-blue/15 flex items-center justify-center text-brand-blue">
            <Brain size={20} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-text-primary">{model.name}</h3>
            <p className="text-[11px] text-text-muted">{model.type}</p>
          </div>
        </div>
        <span className={`badge ${st.class}`}>{st.text}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <MetricBox icon={Target} label="دقت" value={metricDisplay(model.accuracy)} color="blue" />
        <MetricBox icon={Crosshair} label="Precision" value={metricDisplay(model.precision)} color="green" />
        <MetricBox icon={Activity} label="Recall" value={metricDisplay(model.recall)} color="green" />
        <MetricBox icon={Zap} label="F1 Score" value={metricDisplay(model.f1Score ?? model.f1)} color="blue" />
      </div>

      <div className="space-y-2 text-xs text-text-muted mb-4">
        <div className="flex justify-between">
          <span>آخرین آموزش:</span>
          <span className="text-text-secondary">{lastTrained}</span>
        </div>
        <div className="flex justify-between">
          <span>مدت آموزش:</span>
          <span className="text-text-secondary">{duration}</span>
        </div>
        <div className="flex justify-between">
          <span>تعداد داده:</span>
          <span className="text-text-secondary">{dataPoints}</span>
        </div>
      </div>

      <button
        onClick={() => onRetrain(model.id)}
        disabled={isTraining || isRetraining}
        className="btn-primary w-full flex items-center justify-center gap-2 text-sm"
      >
        {isTraining || isRetraining ? (
          <>
            <RefreshCw size={14} className="animate-spin" />
            <span>در حال آموزش...</span>
          </>
        ) : (
          <>
            <RefreshCw size={14} />
            <span>آموزش مجدد</span>
          </>
        )}
      </button>
    </div>
  );
}

function MetricBox({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-surface-elevated rounded-lg px-3 py-2.5 flex items-center gap-2.5">
      <Icon
        size={14}
        className={color === 'blue' ? 'text-brand-blue' : 'text-brand-green'}
      />
      <div>
        <p className="text-[10px] text-text-muted">{label}</p>
        <p className="text-sm font-bold text-text-primary">{value}</p>
      </div>
    </div>
  );
}

function ModelCardSkeleton() {
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <SkeletonBox className="w-10 h-10 rounded-lg" />
          <div className="space-y-2">
            <SkeletonBox className="h-3 w-20" />
            <SkeletonBox className="h-2.5 w-14" />
          </div>
        </div>
        <SkeletonBox className="h-5 w-14 rounded-full" />
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonBox key={i} className="h-12 rounded-lg" />
        ))}
      </div>
      <SkeletonBox className="h-3 w-full mb-2" />
      <SkeletonBox className="h-3 w-full mb-2" />
      <SkeletonBox className="h-3 w-2/3 mb-4" />
      <SkeletonBox className="h-9 w-full rounded-lg" />
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-surface-elevated border border-surface-border rounded-lg px-3 py-2 shadow-xl text-xs">
      <p className="text-text-muted mb-1">{label}</p>
      {payload.map((entry, index) => (
        <p key={index} style={{ color: entry.color }} className="font-medium">
          {entry.name}:{' '}
          {typeof entry.value === 'number'
            ? toPersianDigits((entry.value * 100).toFixed(1)) + '٪'
            : entry.value}
        </p>
      ))}
    </div>
  );
}

export default function MLModelsPage() {
  const queryClient = useQueryClient();
  const notify = useNotificationStore();
  const [selectedModel, setSelectedModel] = useState(null);

  const {
    data: modelsData,
    isLoading: modelsLoading,
    isError: modelsError,
    refetch: refetchModels,
  } = useQuery({
    queryKey: ['ml-models'],
    queryFn: () => mlAPI.getModels().then((r) => r.data),
  });

  const models = Array.isArray(modelsData) ? modelsData : [];
  const effectiveModel = selectedModel ?? models[0]?.id ?? null;

  const {
    data: featureData,
    isLoading: featuresLoading,
    isError: featuresError,
    refetch: refetchFeatures,
  } = useQuery({
    queryKey: ['ml-features', effectiveModel],
    queryFn: () => mlAPI.getFeatureImportance(effectiveModel).then((r) => r.data),
    enabled: !!effectiveModel,
  });

  const {
    data: ensembleData,
    isLoading: ensembleLoading,
    isError: ensembleError,
    refetch: refetchEnsemble,
  } = useQuery({
    queryKey: ['ml-ensemble'],
    queryFn: () => mlAPI.getEnsembleWeights().then((r) => r.data),
  });

  const retrainMutation = useMutation({
    mutationFn: (modelId) => mlAPI.retrain(modelId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ml-models'] });
      notify.success('آموزش مجدد مدل شروع شد');
    },
    onError: () => notify.error('خطا در شروع آموزش مجدد'),
  });

  const features = Array.isArray(featureData) ? featureData : [];
  const ensemble = Array.isArray(ensembleData) ? ensembleData : [];

  // اهمیتِ ویژگی فقط وقتی معنادار است که حداقل یک مقدارِ عددیِ مثبت داشته باشد
  const hasFeatureData = features.some(
    (f) => typeof f.importance === 'number' && Number.isFinite(f.importance) && f.importance > 0
  );

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-text-primary">مدل‌های یادگیری ماشین</h1>

      {/* ── کارت‌های مدل ── */}
      {modelsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <ModelCardSkeleton key={i} />
          ))}
        </div>
      ) : modelsError ? (
        <div className="card">
          <ErrorState
            description="دریافت فهرست مدل‌ها ناموفق بود. دوباره تلاش کنید."
            onRetry={refetchModels}
          />
        </div>
      ) : models.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={Brain}
            title="هیچ مدلی ثبت نشده است"
            description="هنوز مدلِ یادگیری ماشینی آموزش‌دیده یا در رجیستری موجود نیست. پس از آموزش، مدل‌ها اینجا نمایش داده می‌شوند."
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {models.map((model) => (
            <ModelCard
              key={model.id}
              model={model}
              onRetrain={(id) => retrainMutation.mutate(id)}
              isRetraining={retrainMutation.isPending && retrainMutation.variables === model.id}
            />
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ── اهمیت ویژگی‌ها ── */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-text-primary">اهمیت ویژگی‌ها</h3>
            {models.length > 0 && (
              <select
                value={effectiveModel ?? ''}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="text-xs min-w-[120px]"
              >
                {models.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            )}
          </div>

          {!effectiveModel || featuresLoading ? (
            <ChartSkeleton height={310} />
          ) : featuresError ? (
            <ErrorState
              description="دریافت اهمیت ویژگی‌ها ناموفق بود."
              onRetry={refetchFeatures}
            />
          ) : !hasFeatureData ? (
            <EmptyState
              icon={BarChart3}
              title="داده‌ی اهمیت ویژگی موجود نیست"
              description="برای این مدل هنوز مقدارِ اهمیت ویژگی‌ها اندازه‌گیری و ثبت نشده است."
            />
          ) : (
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={features} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" horizontal={false} />
                <XAxis
                  type="number"
                  domain={[0, 0.25]}
                  tick={{ fill: '#636882', fontSize: 10 }}
                  axisLine={{ stroke: '#2a2e3d' }}
                  tickFormatter={(v) => `${toPersianDigits((v * 100).toFixed(0))}٪`}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  tick={{ fill: '#9499ae', fontSize: 11 }}
                  axisLine={{ stroke: '#2a2e3d' }}
                  width={80}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(41,121,255,0.08)' }} />
                <Bar dataKey="importance" fill="#2979FF" name="اهمیت" radius={[0, 4, 4, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* ── وزن‌های Ensemble ── */}
        <div className="card">
          <h3 className="text-sm font-semibold text-text-primary mb-4">وزن‌های Ensemble</h3>
          <p className="text-xs text-text-muted mb-6">
            وزن هر مدل در تصمیم‌گیری نهایی سیستم ترکیبی
          </p>

          {ensembleLoading ? (
            <div className="space-y-5">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <SkeletonBox className="h-3 w-24" />
                    <SkeletonBox className="h-3 w-8" />
                  </div>
                  <SkeletonBox className="h-3 w-full rounded-full" />
                </div>
              ))}
            </div>
          ) : ensembleError ? (
            <ErrorState
              description="دریافت وزن‌های ترکیبی ناموفق بود."
              onRetry={refetchEnsemble}
            />
          ) : ensemble.length === 0 ? (
            <EmptyState
              icon={Layers}
              title="وزنی ثبت نشده است"
              description="هنوز وزنی برای مدل‌ها در سیستم ترکیبی تعیین نشده است."
              compact
            />
          ) : (
            <>
              <div className="space-y-5">
                {ensemble.map((item, idx) => {
                  const weightPct = (item.weight || 0) * 100;
                  return (
                    <div key={idx} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-text-primary">{item.model}</span>
                        <span className="text-sm font-bold text-brand-blue">
                          {toPersianDigits(weightPct.toFixed(0))}٪
                        </span>
                      </div>
                      <div className="w-full h-3 bg-surface-elevated rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${weightPct}%`,
                            background: `linear-gradient(90deg, #2979FF, ${
                              item.weight > 0.25 ? '#00C853' : '#2979FF'
                            })`,
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 p-3 bg-surface-elevated rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Brain size={14} className="text-brand-blue" />
                  <span className="text-xs font-medium text-text-primary">
                    روش ترکیب: Weighted Average
                  </span>
                </div>
                <p className="text-[11px] text-text-muted leading-5">
                  سیگنال نهایی از میانگین وزن‌دار خروجی تمام مدل‌های فعال تولید می‌شود. مدل‌های با
                  عملکرد بهتر وزن بیشتری دریافت می‌کنند.
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
