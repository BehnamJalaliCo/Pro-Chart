import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import {
  Wallet, RefreshCw, CheckCircle2, XCircle, Clock, Copy, Eye,
  ArrowUpRight, Hash, Network, User, Calendar, CreditCard, ShieldCheck,
} from 'lucide-react';
import { paymentsAPI } from '../api/client';
import { useNotificationStore } from '../store';
import DataTable from '../components/common/DataTable';
import Modal from '../components/common/Modal';
import ConfirmDialog from '../components/common/ConfirmDialog';
import StatusBadge from '../components/common/StatusBadge';
import EmptyState from '../components/common/EmptyState';
import ErrorState from '../components/common/ErrorState';
import { TableSkeleton } from '../components/common/Skeleton';
import { toPersianDigits, formatDateTime } from '../utils/formatters';

// ── وضعیت‌ها ───────────────────────────────────────────────────────
const TABS = [
  { key: 'pending', label: 'در انتظار بررسی', icon: Clock },
  { key: 'approved', label: 'تأیید شده', icon: CheckCircle2 },
  { key: 'rejected', label: 'رد شده', icon: XCircle },
];

const STATUS_META = {
  pending: { label: 'در انتظار', variant: 'warning' },
  approved: { label: 'تأیید شده', variant: 'success' },
  rejected: { label: 'رد شده', variant: 'danger' },
};

function statusMeta(s) {
  return STATUS_META[s] || { label: s || '—', variant: 'neutral' };
}

const fmtAmount = (v) =>
  v === null || v === undefined ? '—' : `${toPersianDigits(Number(v).toLocaleString('en-US', { maximumFractionDigits: 2 }))} USDT`;

const shorten = (s, head = 8, tail = 6) =>
  !s ? '—' : s.length <= head + tail + 1 ? s : `${s.slice(0, head)}…${s.slice(-tail)}`;

// ── فیلدِ قابل کپی (tx_hash و ...) ────────────────────────────────
function CopyField({ value, dir = 'ltr', mono = true }) {
  const notify = useNotificationStore();
  if (!value) return <span className="text-text-muted">—</span>;
  const copy = () => {
    navigator.clipboard?.writeText(value);
    notify.success('کپی شد');
  };
  return (
    <div className="flex items-center gap-1.5 min-w-0">
      <span className={`truncate ${mono ? 'font-mono text-[13px]' : ''} text-text-primary`} dir={dir}>
        {value}
      </span>
      <button onClick={copy} className="text-text-muted hover:text-brand-blue shrink-0" title="کپی">
        <Copy size={13} />
      </button>
    </div>
  );
}

// ── سطرِ جزئیات ────────────────────────────────────────────────────
function DetailRow({ icon: Icon, label, children }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-surface-border/60 last:border-0">
      <div className="flex items-center gap-1.5 text-text-muted text-xs w-32 shrink-0 pt-0.5">
        <Icon size={14} /> {label}
      </div>
      <div className="flex-1 min-w-0 text-sm text-text-primary">{children}</div>
    </div>
  );
}

export default function PaymentsPage() {
  const qc = useQueryClient();
  const notify = useNotificationStore();

  const [tab, setTab] = useState('pending');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null); // ردیفِ انتخاب‌شده برای مودالِ جزئیات
  const [note, setNote] = useState('');
  const [confirm, setConfirm] = useState(null); // { type: 'approve' | 'reject', id }

  const perPage = 20;

  const params = useMemo(() => ({ status: tab, page, per_page: perPage }), [tab, page]);

  const { data, isLoading, isError, isFetching, refetch } = useQuery({
    queryKey: ['payments', params],
    queryFn: () => paymentsAPI.getAll(params).then((r) => r.data),
    placeholderData: keepPreviousData,
  });

  const items = data?.items || [];
  const total = data?.total ?? 0;
  const totalPages = data?.total_pages || 1;

  const switchTab = (key) => {
    setTab(key);
    setPage(1);
  };

  const closeModal = () => {
    setSelected(null);
    setNote('');
  };

  const invalidate = () => qc.invalidateQueries({ queryKey: ['payments'] });

  const approveMut = useMutation({
    mutationFn: ({ id, note }) => paymentsAPI.approve(id, note || undefined),
    onSuccess: (res) => {
      notify.success(res?.data?.message || 'پرداخت تأیید و اشتراک فعال شد.');
      setConfirm(null);
      closeModal();
      invalidate();
    },
    onError: (e) => {
      notify.error(e?.response?.data?.detail || 'خطا در تأیید پرداخت.');
      setConfirm(null);
    },
  });

  const rejectMut = useMutation({
    mutationFn: ({ id, note }) => paymentsAPI.reject(id, note || undefined),
    onSuccess: (res) => {
      notify.success(res?.data?.message || 'پرداخت رد شد.');
      setConfirm(null);
      closeModal();
      invalidate();
    },
    onError: (e) => {
      notify.error(e?.response?.data?.detail || 'خطا در رد پرداخت.');
      setConfirm(null);
    },
  });

  const isMutating = approveMut.isPending || rejectMut.isPending;

  const runConfirm = () => {
    if (!confirm) return;
    if (confirm.type === 'approve') approveMut.mutate({ id: confirm.id, note });
    else rejectMut.mutate({ id: confirm.id, note });
  };

  // ── ستون‌های جدول ────────────────────────────────────────────────
  const columns = useMemo(
    () => [
      {
        key: 'id',
        header: 'شناسه',
        width: '80px',
        sortable: false,
        render: (v) => <span className="text-text-muted">#{toPersianDigits(v)}</span>,
      },
      {
        key: 'user',
        header: 'کاربر',
        sortable: false,
        render: (_v, row) => (
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-brand-blue/15 text-brand-blue flex items-center justify-center shrink-0">
              <User size={15} />
            </div>
            <div className="min-w-0">
              <div className="text-text-primary text-sm" dir="ltr">
                {row.telegram_id ? toPersianDigits(row.telegram_id) : `#${toPersianDigits(row.user_id ?? '—')}`}
              </div>
              <div className="text-[11px] text-text-muted">
                {row.telegram_id ? 'آیدی تلگرام' : 'شناسهٔ کاربر'}
              </div>
            </div>
          </div>
        ),
      },
      {
        key: 'plan_label',
        header: 'پلن',
        sortable: false,
        render: (v, row) => (
          <span className="badge badge-blue">{v || row.plan || '—'}</span>
        ),
      },
      {
        key: 'amount_usdt',
        header: 'مبلغ',
        sortable: false,
        render: (v) => <span className="font-medium text-text-primary" dir="ltr">{fmtAmount(v)}</span>,
      },
      {
        key: 'network',
        header: 'شبکه',
        sortable: false,
        render: (v) => (v ? <span className="badge badge-green" dir="ltr">{v}</span> : <span className="text-text-muted">—</span>),
      },
      {
        key: 'tx_hash',
        header: 'هش تراکنش',
        sortable: false,
        render: (v) => (
          <span className="font-mono text-[13px] text-text-secondary" dir="ltr" title={v || ''}>
            {shorten(v)}
          </span>
        ),
      },
      {
        key: 'status',
        header: 'وضعیت',
        sortable: false,
        render: (v) => {
          const m = statusMeta(v);
          return <StatusBadge status={v} label={m.label} variant={m.variant} />;
        },
      },
      {
        key: 'created_at',
        header: 'تاریخ ثبت',
        sortable: false,
        render: (v) => (
          <span className="text-text-muted text-xs whitespace-nowrap">{v ? toPersianDigits(formatDateTime(v)) : '—'}</span>
        ),
      },
      {
        key: 'actions',
        header: 'اقدام',
        sortable: false,
        headerClassName: 'text-center',
        cellClassName: 'text-center',
        render: (_v, row) => (
          <div className="flex items-center justify-center gap-1" onClick={(e) => e.stopPropagation()}>
            <button
              title="مشاهدهٔ جزئیات"
              onClick={() => { setSelected(row); setNote(''); }}
              className="p-1.5 rounded-lg text-text-muted hover:bg-surface-hover hover:text-brand-blue transition-colors"
            >
              <Eye size={16} />
            </button>
            {row.status === 'pending' && (
              <>
                <button
                  title="تأیید"
                  onClick={() => { setNote(''); setConfirm({ type: 'approve', id: row.id }); }}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-surface-hover hover:text-brand-green transition-colors"
                >
                  <CheckCircle2 size={16} />
                </button>
                <button
                  title="رد"
                  onClick={() => { setNote(''); setConfirm({ type: 'reject', id: row.id }); }}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-surface-hover hover:text-brand-red transition-colors"
                >
                  <XCircle size={16} />
                </button>
              </>
            )}
          </div>
        ),
      },
    ],
    []
  );

  const activeTabMeta = TABS.find((t) => t.key === tab);
  const EmptyIcon = activeTabMeta?.icon || Wallet;
  const emptyCopy = {
    pending: {
      title: 'درخواستِ در انتظاری نیست',
      description: 'هر درخواستِ پرداختِ جدید که کاربران ثبت کنند، برای بررسی اینجا ظاهر می‌شود.',
    },
    approved: {
      title: 'پرداختِ تأییدشده‌ای نیست',
      description: 'درخواست‌های تأییدشده پس از بررسی در این بخش نمایش داده می‌شوند.',
    },
    rejected: {
      title: 'پرداختِ ردشده‌ای نیست',
      description: 'درخواست‌هایی که رد کنید در این بخش فهرست می‌شوند.',
    },
  }[tab];

  return (
    <div className="space-y-5">
      {/* هدر */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-text-primary flex items-center gap-2">
            <Wallet size={22} className="text-brand-green" /> بررسی پرداخت‌ها
          </h1>
          <p className="text-sm text-text-muted">تأیید یا ردِ درخواست‌های پرداختِ ارزِ دیجیتال کاربران</p>
        </div>
        <button onClick={() => refetch()} className="btn-ghost flex items-center gap-2 text-sm">
          <RefreshCw size={15} className={isFetching ? 'animate-spin' : ''} /> به‌روزرسانی
        </button>
      </div>

      {/* تب‌ها */}
      <div className="flex items-center gap-2 flex-wrap">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => switchTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors border ${
                active
                  ? 'bg-brand-blue/15 text-brand-blue border-brand-blue/30'
                  : 'bg-surface-card text-text-secondary border-surface-border hover:bg-surface-hover'
              }`}
            >
              <Icon size={16} />
              {t.label}
              {active && total > 0 && (
                <span className="text-xs bg-brand-blue/20 rounded-full px-1.5 py-0.5">
                  {toPersianDigits(total)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* جدول */}
      <div className="card p-0 overflow-hidden">
        {isError ? (
          <div className="p-4">
            <ErrorState description="فهرستِ پرداخت‌ها دریافت نشد. دوباره تلاش کنید." onRetry={refetch} />
          </div>
        ) : isLoading ? (
          <TableSkeleton columns={9} rows={8} />
        ) : items.length === 0 ? (
          <EmptyState icon={EmptyIcon} title={emptyCopy.title} description={emptyCopy.description} />
        ) : (
          <DataTable
            columns={columns}
            data={items}
            sortable={false}
            onRowClick={(row) => { setSelected(row); setNote(''); }}
            pagination={{ page, totalPages, totalItems: total }}
            onPageChange={setPage}
          />
        )}
      </div>

      {/* مودالِ جزئیات */}
      <Modal
        isOpen={!!selected}
        onClose={closeModal}
        title={selected ? `جزئیات پرداخت #${toPersianDigits(selected.id)}` : ''}
        size="lg"
        footer={
          selected && selected.status === 'pending' ? (
            <>
              <button
                className="btn-danger flex items-center gap-2"
                onClick={() => setConfirm({ type: 'reject', id: selected.id })}
              >
                <XCircle size={16} /> رد درخواست
              </button>
              <button
                className="btn-success flex items-center gap-2"
                onClick={() => setConfirm({ type: 'approve', id: selected.id })}
              >
                <CheckCircle2 size={16} /> تأیید و فعال‌سازی
              </button>
            </>
          ) : (
            <button className="btn-ghost" onClick={closeModal}>بستن</button>
          )
        }
      >
        {selected && (
          <div className="space-y-4">
            {/* خلاصهٔ مبلغ + وضعیت */}
            <div className="flex items-center justify-between bg-surface-elevated rounded-xl px-4 py-3">
              <div>
                <div className="text-xs text-text-muted mb-1">مبلغِ درخواست</div>
                <div className="text-2xl font-bold text-text-primary" dir="ltr">{fmtAmount(selected.amount_usdt)}</div>
              </div>
              <StatusBadge
                status={selected.status}
                label={statusMeta(selected.status).label}
                variant={statusMeta(selected.status).variant}
              />
            </div>

            <div className="bg-surface-card border border-surface-border rounded-xl px-4">
              <DetailRow icon={User} label="کاربر">
                <div className="flex flex-col gap-0.5">
                  {selected.telegram_id && (
                    <span dir="ltr">آیدی تلگرام: {toPersianDigits(selected.telegram_id)}</span>
                  )}
                  <span className="text-text-muted text-xs">شناسهٔ کاربر: {toPersianDigits(selected.user_id ?? '—')}</span>
                </div>
              </DetailRow>
              <DetailRow icon={CreditCard} label="پلن">
                <span className="badge badge-blue">{selected.plan_label || selected.plan || '—'}</span>
              </DetailRow>
              <DetailRow icon={Network} label="شبکه">
                {selected.network ? (
                  <span className="badge badge-green" dir="ltr">{selected.network}</span>
                ) : (
                  <span className="text-text-muted">—</span>
                )}
              </DetailRow>
              <DetailRow icon={Hash} label="هش تراکنش">
                <CopyField value={selected.tx_hash} />
              </DetailRow>
              <DetailRow icon={Calendar} label="تاریخ ثبت">
                <span className="text-text-secondary">
                  {selected.created_at ? toPersianDigits(formatDateTime(selected.created_at)) : '—'}
                </span>
              </DetailRow>
              {selected.reviewed_at && (
                <DetailRow icon={ShieldCheck} label="تاریخ بررسی">
                  <span className="text-text-secondary">{toPersianDigits(formatDateTime(selected.reviewed_at))}</span>
                </DetailRow>
              )}
              {selected.admin_note && (
                <DetailRow icon={ArrowUpRight} label="یادداشت ادمین">
                  <span className="text-text-secondary">{selected.admin_note}</span>
                </DetailRow>
              )}
            </div>

            {/* یادداشتِ اختیاری هنگام بررسی */}
            {selected.status === 'pending' && (
              <div>
                <label className="text-xs text-text-muted block mb-1.5">
                  یادداشت (اختیاری) — در صورتِ رد، برای کاربر ارسال می‌شود
                </label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={3}
                  maxLength={500}
                  placeholder="مثلاً: هش تراکنش نامعتبر است یا مبلغ مطابقت ندارد…"
                  className="w-full"
                />
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* تأییدِ نهاییِ اقدام */}
      <ConfirmDialog
        isOpen={!!confirm}
        onClose={() => !isMutating && setConfirm(null)}
        onConfirm={runConfirm}
        loading={isMutating}
        variant={confirm?.type === 'approve' ? 'info' : 'danger'}
        title={confirm?.type === 'approve' ? 'تأیید پرداخت' : 'رد پرداخت'}
        message={
          confirm?.type === 'approve'
            ? 'با تأیید، اشتراکِ کاربر فعال شده و پیامِ دعوت برای او ارسال می‌شود. ادامه می‌دهید؟'
            : 'این درخواستِ پرداخت رد می‌شود و کاربر مطلع خواهد شد. ادامه می‌دهید؟'
        }
        confirmText={confirm?.type === 'approve' ? 'تأیید و فعال‌سازی' : 'رد درخواست'}
      />
    </div>
  );
}
