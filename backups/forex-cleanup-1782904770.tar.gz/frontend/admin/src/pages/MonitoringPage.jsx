import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { monitoringAPI } from '../api/client';
import {
  Cpu,
  HardDrive,
  MemoryStick,
  Container,
  Wifi,
  WifiOff,
  RefreshCw,
  Clock,
  Server,
  Radio,
  FileText,
  Activity,
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';
import ErrorState from '../components/common/ErrorState';
import EmptyState from '../components/common/EmptyState';
import { SkeletonBox, TableSkeleton } from '../components/common/Skeleton';

function GaugeChart({ value, label, icon: Icon, max = 100, colorThresholds }) {
  const safeValue = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  const percentage = Math.min((safeValue / max) * 100, 100);
  const circumference = 2 * Math.PI * 40;
  const offset = circumference - (percentage / 100) * circumference;

  const getColor = () => {
    if (colorThresholds) {
      if (safeValue >= colorThresholds.danger) return '#FF1744';
      if (safeValue >= colorThresholds.warning) return '#FFC107';
      return '#00C853';
    }
    return '#2979FF';
  };

  return (
    <div className="flex flex-col items-center">
      <div className="gauge-ring">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle cx="50" cy="50" r="40" fill="none" stroke="#1c2030" strokeWidth="8" />
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke={getColor()}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-700"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-lg font-bold text-text-primary">{toPersianDigits(safeValue)}٪</span>
        </div>
      </div>
      <div className="flex items-center gap-1.5 mt-2">
        <Icon size={14} className="text-text-muted" />
        <span className="text-xs text-text-muted">{label}</span>
      </div>
    </div>
  );
}

function SystemSkeleton() {
  return (
    <div className="grid grid-cols-3 gap-6" aria-label="در حال بارگذاری" role="status">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="flex flex-col items-center gap-3">
          <SkeletonBox className="w-24 h-24 rounded-full" />
          <SkeletonBox className="w-16 h-3" />
          <SkeletonBox className="w-20 h-2.5" />
        </div>
      ))}
    </div>
  );
}

export default function MonitoringPage() {
  const [logFilter, setLogFilter] = useState('all');

  const systemQuery = useQuery({
    queryKey: ['monitoring-system'],
    queryFn: () => monitoringAPI.getSystemMetrics().then((r) => r.data),
    refetchInterval: 10000,
  });

  const containersQuery = useQuery({
    queryKey: ['monitoring-containers'],
    queryFn: () => monitoringAPI.getContainers().then((r) => r.data),
    refetchInterval: 15000,
  });

  const feedsQuery = useQuery({
    queryKey: ['monitoring-feeds'],
    queryFn: () => monitoringAPI.getDataFeeds().then((r) => r.data),
    refetchInterval: 10000,
  });

  const logsQuery = useQuery({
    queryKey: ['monitoring-logs', logFilter],
    queryFn: () => monitoringAPI.getLogs({ level: logFilter }).then((r) => r.data),
    refetchInterval: 5000,
  });

  const system = systemQuery.data || null;
  const containers = Array.isArray(containersQuery.data) ? containersQuery.data : [];
  const dataFeeds = Array.isArray(feedsQuery.data) ? feedsQuery.data : [];
  const logs = Array.isArray(logsQuery.data) ? logsQuery.data : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-text-primary">مانیتورینگ</h1>
        {system?.uptime && (
          <div className="flex items-center gap-2 text-xs text-text-muted">
            <Clock size={14} />
            <span>آپتایم: {toPersianDigits(system.uptime)}</span>
          </div>
        )}
      </div>

      {/* منابع سیستم */}
      <div className="card">
        <h3 className="text-sm font-semibold text-text-primary mb-6">منابع سیستم</h3>
        {systemQuery.isLoading ? (
          <SystemSkeleton />
        ) : systemQuery.isError ? (
          <ErrorState
            compact
            description="اطلاعات منابع سیستم دریافت نشد."
            onRetry={systemQuery.refetch}
          />
        ) : !system ? (
          <EmptyState
            compact
            icon={Activity}
            title="داده‌ای برای نمایش نیست"
            description="اطلاعات منابع سیستم در دسترس نیست."
          />
        ) : (
          <div className="grid grid-cols-3 gap-6">
            <div className="flex flex-col items-center">
              <GaugeChart
                value={system.cpu}
                label="CPU"
                icon={Cpu}
                colorThresholds={{ warning: 70, danger: 90 }}
              />
              <p className="text-[10px] text-text-muted mt-1">
                {toPersianDigits(system.cpuCores ?? 0)} هسته | Load: {toPersianDigits(system.loadAvg ?? '—')}
              </p>
            </div>
            <div className="flex flex-col items-center">
              <GaugeChart
                value={system.ram}
                label="RAM"
                icon={MemoryStick}
                colorThresholds={{ warning: 75, danger: 90 }}
              />
              <p className="text-[10px] text-text-muted mt-1">
                {toPersianDigits(system.ramUsed ?? '—')} / {toPersianDigits(system.ramTotal ?? '—')}
              </p>
            </div>
            <div className="flex flex-col items-center">
              <GaugeChart
                value={system.disk}
                label="دیسک"
                icon={HardDrive}
                colorThresholds={{ warning: 80, danger: 95 }}
              />
              <p className="text-[10px] text-text-muted mt-1">
                {toPersianDigits(system.diskUsed ?? '—')} / {toPersianDigits(system.diskTotal ?? '—')}
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* کانتینرهای Docker */}
        <div className="card">
          <h3 className="text-sm font-semibold text-text-primary mb-4">کانتینرهای Docker</h3>
          {containersQuery.isLoading ? (
            <TableSkeleton columns={5} rows={6} />
          ) : containersQuery.isError ? (
            <ErrorState
              compact
              description="فهرست کانتینرها دریافت نشد."
              onRetry={containersQuery.refetch}
            />
          ) : containers.length === 0 ? (
            <EmptyState
              compact
              icon={Server}
              title="کانتینری یافت نشد"
              description="دسترسی به Docker در دسترس نیست یا کانتینری در حال اجرا نیست."
            />
          ) : (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>نام</th>
                    <th>وضعیت</th>
                    <th>CPU</th>
                    <th>حافظه</th>
                    <th>آپتایم</th>
                  </tr>
                </thead>
                <tbody>
                  {containers.map((c, idx) => (
                    <tr key={c.name || idx}>
                      <td>
                        <div className="flex items-center gap-2">
                          <Container size={14} className="text-text-muted shrink-0" />
                          <span className="text-sm font-medium text-text-primary font-mono">
                            {c.name}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span
                          className={`badge ${
                            c.status === 'running' ? 'badge-green' : 'badge-red'
                          }`}
                        >
                          {c.status === 'running' ? 'فعال' : 'متوقف'}
                        </span>
                      </td>
                      <td className="text-xs font-mono text-text-muted">{toPersianDigits(c.cpu)}</td>
                      <td className="text-xs font-mono text-text-muted">{toPersianDigits(c.memory)}</td>
                      <td className="text-xs text-text-muted">{toPersianDigits(c.uptime)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* وضعیت دیتافیدها */}
        <div className="card">
          <h3 className="text-sm font-semibold text-text-primary mb-4">وضعیت دیتافیدها</h3>
          {feedsQuery.isLoading ? (
            <div className="space-y-3" aria-label="در حال بارگذاری" role="status">
              {Array.from({ length: 3 }).map((_, i) => (
                <SkeletonBox key={i} className="h-16 w-full rounded-lg" />
              ))}
            </div>
          ) : feedsQuery.isError ? (
            <ErrorState
              compact
              description="وضعیت دیتافیدها دریافت نشد."
              onRetry={feedsQuery.refetch}
            />
          ) : dataFeeds.length === 0 ? (
            <EmptyState
              compact
              icon={Radio}
              title="دیتافیدی موجود نیست"
              description="هیچ منبع داده‌ای پیکربندی یا فعال نشده است."
            />
          ) : (
            <div className="space-y-3">
              {dataFeeds.map((feed, idx) => (
                <div
                  key={feed.name || idx}
                  className="flex items-center justify-between p-3 bg-surface-elevated rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    {feed.status === 'connected' ? (
                      <Wifi size={16} className="text-brand-green" />
                    ) : feed.status === 'degraded' ? (
                      <Wifi size={16} className="text-yellow-400" />
                    ) : (
                      <WifiOff size={16} className="text-brand-red" />
                    )}
                    <div>
                      <p className="text-sm font-medium text-text-primary">{feed.name}</p>
                      <p className="text-[10px] text-text-muted">
                        {toPersianDigits(feed.symbols ?? 0)} نماد | آخرین بروزرسانی: {toPersianDigits(feed.lastUpdate ?? '—')}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <span
                      className={`badge ${
                        feed.status === 'connected'
                          ? 'badge-green'
                          : feed.status === 'degraded'
                          ? 'bg-yellow-500/15 text-yellow-400'
                          : 'badge-red'
                      }`}
                    >
                      {feed.status === 'connected'
                        ? 'متصل'
                        : feed.status === 'degraded'
                        ? 'کند'
                        : 'قطع'}
                    </span>
                    <p className="text-[10px] text-text-muted mt-1 font-mono">
                      {toPersianDigits(feed.latency ?? '—')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* لاگ‌های اخیر */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-text-primary">لاگ‌های اخیر</h3>
          <div className="flex items-center gap-2">
            <select
              value={logFilter}
              onChange={(e) => setLogFilter(e.target.value)}
              className="text-xs min-w-[100px]"
            >
              <option value="all">همه</option>
              <option value="info">اطلاعات</option>
              <option value="warning">هشدار</option>
              <option value="error">خطا</option>
            </select>
            <button
              type="button"
              onClick={() => logsQuery.refetch()}
              className="p-1.5 rounded-md hover:bg-surface-hover text-text-muted transition-colors"
              title="بروزرسانی"
            >
              <RefreshCw size={14} className={logsQuery.isFetching ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {logsQuery.isLoading ? (
          <div className="space-y-2" aria-label="در حال بارگذاری" role="status">
            {Array.from({ length: 8 }).map((_, i) => (
              <SkeletonBox key={i} className="h-6 w-full rounded-lg" />
            ))}
          </div>
        ) : logsQuery.isError ? (
          <ErrorState
            compact
            description="لاگ‌ها دریافت نشد."
            onRetry={logsQuery.refetch}
          />
        ) : logs.length === 0 ? (
          <EmptyState
            compact
            icon={FileText}
            title="لاگی برای نمایش نیست"
            description={
              logFilter === 'all'
                ? 'هنوز رویدادی ثبت نشده است.'
                : 'لاگی با این سطح یافت نشد.'
            }
          />
        ) : (
          <div className="space-y-1 max-h-[400px] overflow-y-auto">
            {logs.map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-3 px-3 py-2 rounded-lg hover:bg-surface-hover text-xs transition-colors"
              >
                <span className="text-text-muted font-mono shrink-0 mt-0.5 w-16">
                  {toPersianDigits(log.timestamp)}
                </span>
                <span
                  className={`shrink-0 mt-0.5 w-12 font-medium ${
                    log.level === 'error'
                      ? 'text-brand-red'
                      : log.level === 'warning'
                      ? 'text-yellow-400'
                      : 'text-brand-green'
                  }`}
                >
                  {log.level === 'error' ? 'خطا' : log.level === 'warning' ? 'هشدار' : 'اطلاع'}
                </span>
                <span className="text-text-muted font-mono shrink-0 w-24">[{log.service}]</span>
                <span className="text-text-secondary">{log.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
