import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { subscriptionsAPI } from '../api/client';
import { useNotificationStore } from '../store';
import {
  Search, X, ChevronLeft, ChevronRight, RefreshCw, CreditCard,
  CheckCircle2, XCircle, Sparkles, DollarSign, Calendar, Clock,
  User as UserIcon, Link2, Hash, CalendarPlus, MoreHorizontal, Tag,
} from 'lucide-react';
import EmptyState from '../components/common/EmptyState';
import ErrorState from '../components/common/ErrorState';
import { TableSkeleton, CardSkeleton } from '../components/common/Skeleton';

// ── helpers ──────────────────────────────────────────────────────
const PLAN_LABEL = { trial: 'آزمایشی', monthly: 'ماهانه', quarterly: 'سه‌ماهه', biannual: 'شش‌ماهه', annual: 'سالانه' };
const STATUS_LABEL = { active: 'فعال', expired: 'منقضی', cancelled: 'لغو‌شده', pending: 'در انتظار', trial: 'آزمایشی' };

function planCls(p) {
  return ({
    trial: 'bg-brand-blue/15 text-brand-blue',
    monthly: 'bg-brand-green/15 text-brand-green',
    quarterly: 'bg-amber-500/15 text-amber-500',
    biannual: 'bg-purple-500/15 text-purple-400',
    annual: 'bg-purple-500/15 text-purple-400',
  })[p] || 'bg-surface-hover text-text-muted';
}
function statusCls(s) {
  return ({
    active: 'bg-brand-green/15 text-brand-green',
    expired: 'bg-brand-red/15 text-brand-red',
    cancelled: 'bg-surface-hover text-text-muted',
    pending: 'bg-amber-500/15 text-amber-500',
    trial: 'bg-brand-blue/15 text-brand-blue',
  })[s] || 'bg-surface-hover text-text-muted';
}

const fa = (n) => (n ?? 0).toLocaleString('fa-IR');
const fmtDate = (iso) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString('fa-IR'); } catch { return iso; }
};
const fmtUsdt = (v) => (v == null ? '—' : `${Number(v).toLocaleString('fa-IR', { maximumFractionDigits: 2 })} USDT`);
const daysLeft = (iso) => {
  if (!iso) return null;
  return Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
};

const useDebounce = (v, ms = 400) => {
  const [d, setD] = useState(v);
  useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t); }, [v, ms]);
  return d;
};

// ── stat card ────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, tone = 'blue' }) {
  const tones = {
    blue: 'text-brand-blue bg-brand-blue/10',
    green: 'text-brand-green bg-brand-green/10',
    red: 'text-brand-red bg-brand-red/10',
    amber: 'text-amber-500 bg-amber-500/10',
    purple: 'text-purple-400 bg-purple-500/10',
  };
  return (
    <div className="card flex items-center gap-3 py-4">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${tones[tone]}`}>
        <Icon size={20} />
      </div>
      <div className="min-w-0">
        <div className="text-xl font-bold text-text-primary leading-none truncate">{value}</div>
        <div className="text-xs text-text-muted mt-1 truncate">{label}</div>
      </div>
    </div>
  );
}

function ActionBtn({ title, icon: Icon, tone, onClick }) {
  const t = { red: 'hover:text-brand-red', green: 'hover:text-brand-green', blue: 'hover:text-brand-blue' }[tone];
  return (
    <button title={title} onClick={onClick} className={`p-1.5 rounded-lg text-text-muted hover:bg-surface-hover transition-colors ${t}`}>
      <Icon size={16} />
    </button>
  );
}

// ── main ─────────────────────────────────────────────────────────
export default function SubscriptionsPage() {
  const qc = useQueryClient();
  const notify = useNotificationStore();

  const [search, setSearch] = useState('');
  const debSearch = useDebounce(search);
  const [status, setStatus] = useState('all');
  const [plan, setPlan] = useState('all');
  const [page, setPage] = useState(1);
  const [selectedId, setSelectedId] = useState(null);

  useEffect(() => { setPage(1); }, [debSearch, status, plan]);

  const params = useMemo(() => {
    const p = { page, per_page: 15 };
    if (debSearch) p.search = debSearch;
    if (status !== 'all') p.status = status;
    if (plan !== 'all') p.plan = plan;
    return p;
  }, [page, debSearch, status, plan]);

  const {
    data: stats, isLoading: statsLoading, isError: statsError, refetch: refetchStats,
  } = useQuery({
    queryKey: ['subs-stats'],
    queryFn: () => subscriptionsAPI.getStats().then((r) => r.data),
  });

  const {
    data, isLoading, isError, isFetching, refetch,
  } = useQuery({
    queryKey: ['subs', params],
    queryFn: () => subscriptionsAPI.getAll(params).then((r) => r.data),
    keepPreviousData: true,
  });

  const rows = data?.items || [];
  const totalPages = data?.total_pages || 1;

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['subs'] });
    qc.invalidateQueries({ queryKey: ['subs-stats'] });
    if (selectedId) qc.invalidateQueries({ queryKey: ['sub', selectedId] });
  };

  const hasFilters = status !== 'all' || plan !== 'all' || !!debSearch;
  const clearFilters = () => { setSearch(''); setStatus('all'); setPlan('all'); };

  const expiredCount = stats?.by_status?.expired ?? 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-text-primary">مدیریت اشتراک‌ها</h1>
          <p className="text-sm text-text-muted">مشاهده، فیلتر و تمدیدِ دستیِ اشتراک‌های کاربران</p>
        </div>
        <button onClick={() => { refetch(); refetchStats(); }} className="btn-ghost flex items-center gap-2 text-sm">
          <RefreshCw size={15} className={isFetching ? 'animate-spin' : ''} /> به‌روزرسانی
        </button>
      </div>

      {statsError ? (
        <div className="card">
          <ErrorState compact description="آمارِ اشتراک‌ها دریافت نشد." onRetry={refetchStats} />
        </div>
      ) : statsLoading ? (
        <CardSkeleton count={4} />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon={CheckCircle2} label="اشتراک فعال" value={fa(stats?.active_now)} tone="green" />
          <StatCard icon={XCircle} label="منقضی‌شده" value={fa(expiredCount)} tone="red" />
          <StatCard icon={Sparkles} label="آزمایشیِ فعال" value={fa(stats?.trial_active)} tone="blue" />
          <StatCard icon={DollarSign} label="مجموع درآمد" value={fmtUsdt(stats?.total_revenue_usdt)} tone="amber" />
        </div>
      )}

      <div className="card">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[220px]">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted" />
            <input
              value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو بر اساس نام یا یوزرنیمِ کاربر…"
              className="w-full pr-9"
            />
          </div>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="w-auto">
            <option value="all">همه وضعیت‌ها</option>
            {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={plan} onChange={(e) => setPlan(e.target.value)} className="w-auto">
            <option value="all">همه پلن‌ها</option>
            {Object.entries(PLAN_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          {hasFilters && (
            <button onClick={clearFilters} className="btn-ghost text-xs flex items-center gap-1"><X size={13} /> پاک‌کردن فیلتر</button>
          )}
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-text-secondary border-b border-surface-border">
                <th className="px-4 py-3 text-right font-medium">کاربر</th>
                <th className="px-4 py-3 text-right font-medium">پلن</th>
                <th className="px-4 py-3 text-right font-medium">وضعیت</th>
                <th className="px-4 py-3 text-right font-medium">شروع</th>
                <th className="px-4 py-3 text-right font-medium">انقضا</th>
                <th className="px-4 py-3 text-right font-medium">مبلغ</th>
                <th className="px-4 py-3 text-center font-medium">اقدام</th>
              </tr>
            </thead>
            <tbody>
              {isError ? (
                <tr><td colSpan={7} className="p-4">
                  <ErrorState compact description="فهرستِ اشتراک‌ها دریافت نشد. دوباره تلاش کنید." onRetry={refetch} />
                </td></tr>
              ) : isLoading ? (
                <tr><td colSpan={7} className="p-0"><TableSkeleton columns={7} rows={8} /></td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={7} className="p-4">
                  <EmptyState
                    icon={hasFilters ? Search : CreditCard}
                    title={hasFilters ? 'نتیجه‌ای یافت نشد' : 'هنوز اشتراکی ثبت نشده'}
                    description={
                      hasFilters
                        ? 'با این فیلترها اشتراکی پیدا نشد. فیلترها را پاک کنید یا عبارتِ دیگری بجویید.'
                        : 'با خریدِ اشتراک توسطِ کاربران، فهرست اینجا نمایش داده می‌شود.'
                    }
                    action={hasFilters ? (
                      <button onClick={clearFilters} className="btn-ghost text-xs flex items-center gap-1"><X size={13} /> پاک‌کردن فیلتر</button>
                    ) : null}
                  />
                </td></tr>
              ) : rows.map((s) => {
                const dl = daysLeft(s.expires_at);
                return (
                  <tr key={s.id} onClick={() => setSelectedId(s.id)}
                    className="border-b border-surface-border/60 hover:bg-surface-hover cursor-pointer transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-brand-blue/15 text-brand-blue shrink-0">
                          <UserIcon size={16} />
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium text-text-primary truncate">کاربر #{fa(s.user_id)}</div>
                          <div className="text-xs text-text-muted truncate" dir="ltr">{s.telegram_id ?? '—'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3"><span className={`badge ${planCls(s.plan)}`}>{s.plan_label || PLAN_LABEL[s.plan] || s.plan}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-1">
                        <span className={`badge ${statusCls(s.status)} w-fit`}>{STATUS_LABEL[s.status] || s.status}</span>
                        {s.status === 'active' && dl != null && dl >= 0 && (
                          <span className="text-[11px] text-text-muted">{fa(dl)} روز مانده</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-text-muted text-xs whitespace-nowrap">{fmtDate(s.started_at)}</td>
                    <td className="px-4 py-3 text-text-muted text-xs whitespace-nowrap">{fmtDate(s.expires_at)}</td>
                    <td className="px-4 py-3 text-text-secondary text-xs whitespace-nowrap" dir="ltr">{fmtUsdt(s.amount_usdt)}</td>
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1">
                        <ActionBtn title="تمدید" tone="green" icon={CalendarPlus} onClick={() => setSelectedId(s.id)} />
                        <ActionBtn title="جزئیات" tone="blue" icon={MoreHorizontal} onClick={() => setSelectedId(s.id)} />
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between px-4 py-3 border-t border-surface-border text-sm">
          <span className="text-text-muted">{fa(data?.total)} اشتراک</span>
          <div className="flex items-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost p-2 disabled:opacity-40"><ChevronRight size={16} /></button>
            <span className="text-text-secondary">{fa(page)} / {fa(totalPages)}</span>
            <button disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="btn-ghost p-2 disabled:opacity-40"><ChevronLeft size={16} /></button>
          </div>
        </div>
      </div>

      {selectedId && (
        <SubscriptionDrawer id={selectedId} onClose={() => setSelectedId(null)} onChanged={invalidate} />
      )}
    </div>
  );
}

// ── detail drawer ────────────────────────────────────────────────
function Info({ icon: Icon, label, value, dir }) {
  return (
    <div className="bg-surface-elevated rounded-xl px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-text-muted text-[11px] mb-1"><Icon size={12} /> {label}</div>
      <div className="text-sm text-text-primary truncate" dir={dir}>{value}</div>
    </div>
  );
}

function SubscriptionDrawer({ id, onClose, onChanged }) {
  const notify = useNotificationStore();
  const qc = useQueryClient();
  const {
    data: s, isLoading, isError, refetch,
  } = useQuery({ queryKey: ['sub', id], queryFn: () => subscriptionsAPI.getById(id).then((r) => r.data) });

  const [days, setDays] = useState(30);
  const [busy, setBusy] = useState(false);

  const extend = async () => {
    if (busy || days < 1) return;
    setBusy(true);
    try {
      const res = await subscriptionsAPI.extend(id, days);
      notify.success(res?.data?.message || `${fa(days)} روز تمدید شد`);
      qc.invalidateQueries({ queryKey: ['sub', id] });
      onChanged();
    } catch (e) {
      notify.error(e?.response?.data?.detail || 'خطا در تمدید اشتراک');
    } finally { setBusy(false); }
  };

  const dl = s ? daysLeft(s.expires_at) : null;

  return (
    <div className="fixed inset-0 z-50 flex" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative ml-0 mr-auto w-full max-w-md h-full bg-surface-card border-l border-surface-border overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()} dir="rtl">
        <div className="sticky top-0 bg-surface-card/95 backdrop-blur border-b border-surface-border px-5 py-4 flex items-center justify-between z-10">
          <h2 className="font-bold text-text-primary">جزئیات اشتراک</h2>
          <button onClick={onClose} className="btn-ghost p-2"><X size={18} /></button>
        </div>

        {isError ? (
          <div className="p-6">
            <ErrorState compact description="اطلاعاتِ اشتراک دریافت نشد." onRetry={refetch} />
          </div>
        ) : isLoading || !s ? (
          <div className="p-10 text-center text-text-muted">در حال بارگذاری…</div>
        ) : (
          <div className="p-5 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center bg-brand-blue/15 text-brand-blue">
                <CreditCard size={24} />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-text-primary text-lg">اشتراک #{fa(s.id)}</div>
                <div className="text-sm text-text-muted">کاربر #{fa(s.user_id)}</div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className={`badge ${planCls(s.plan)}`}>{s.plan_label || PLAN_LABEL[s.plan] || s.plan}</span>
              <span className={`badge ${statusCls(s.status)}`}>{STATUS_LABEL[s.status] || s.status}</span>
              {s.status === 'active' && dl != null && dl >= 0 && (
                <span className="badge bg-brand-green/15 text-brand-green">{fa(dl)} روز مانده</span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Info icon={Link2} label="آیدی تلگرام" value={s.telegram_id ?? '—'} dir="ltr" />
              <Info icon={Tag} label="پلن" value={s.plan_label || PLAN_LABEL[s.plan] || s.plan} />
              <Info icon={Calendar} label="تاریخِ شروع" value={fmtDate(s.started_at)} />
              <Info icon={Clock} label="تاریخِ انقضا" value={fmtDate(s.expires_at)} />
              <Info icon={DollarSign} label="مبلغ" value={fmtUsdt(s.amount_usdt)} dir="ltr" />
              <Info icon={Hash} label="شناسهٔ پرداخت" value={s.payment_request_id ?? '—'} dir="ltr" />
            </div>

            <div className="border-t border-surface-border pt-4">
              <div className="text-sm font-semibold text-text-primary mb-2 flex items-center gap-2">
                <CalendarPlus size={15} className="text-brand-green" /> تمدیدِ دستی
              </div>
              <div className="flex gap-2 mb-2 flex-wrap">
                {[7, 30, 90, 180, 365].map((d) => (
                  <button key={d} onClick={() => setDays(d)}
                    className={`flex-1 min-w-[48px] py-1.5 rounded-lg text-xs ${days === d ? 'bg-brand-green text-white' : 'bg-surface-elevated text-text-secondary'}`}>
                    {fa(d)}
                  </button>
                ))}
              </div>
              <input type="number" value={days} min={1}
                onChange={(e) => setDays(Math.max(1, Number(e.target.value) || 1))} className="w-full mb-2" />
              <button disabled={busy || days < 1} className="btn-success w-full" onClick={extend}>
                {busy ? '...' : `تمدید ${fa(days)} روز`}
              </button>
              <p className="text-[11px] text-text-muted mt-2">
                تمدید از تاریخِ انقضای فعلی (در صورتِ فعال بودن) یا از امروز محاسبه می‌شود و وضعیت را «فعال» می‌کند.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
