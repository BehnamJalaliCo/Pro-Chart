import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { dashboardAPI } from '../api/client';
import {
  Users,
  Signal,
  TrendingUp,
  DollarSign,
  Activity,
  Server,
  BarChart3,
  UserPlus,
} from 'lucide-react';
import StatCard from '../components/common/StatCard';
import EmptyState from '../components/common/EmptyState';
import ErrorState from '../components/common/ErrorState';
import { CardSkeleton, ChartSkeleton, TableSkeleton } from '../components/common/Skeleton';
import { toPersianDigits, formatNumber } from '../utils/formatters';

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-surface-elevated border border-surface-border rounded-lg px-3 py-2 shadow-xl text-xs">
      <p className="text-text-muted mb-1">{toPersianDigits(label)}</p>
      {payload.map((entry, index) => (
        <p key={index} style={{ color: entry.color }} className="font-medium">
          {entry.name}: {toPersianDigits(entry.value)}
        </p>
      ))}
    </div>
  );
}

const axisTick = { fill: '#636882', fontSize: 10 };
const axisLine = { stroke: '#2a2e3d' };
const faTick = (v) => toPersianDigits(v);

export default function DashboardPage() {
  const statsQuery = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: () => dashboardAPI.getStats().then((r) => r.data),
  });

  const signalChartQuery = useQuery({
    queryKey: ['dashboard-signal-chart'],
    queryFn: () => dashboardAPI.getSignalChart().then((r) => r.data),
  });

  const userGrowthQuery = useQuery({
    queryKey: ['dashboard-user-growth'],
    queryFn: () => dashboardAPI.getUserGrowth().then((r) => r.data),
  });

  const servicesQuery = useQuery({
    queryKey: ['dashboard-services'],
    queryFn: () => dashboardAPI.getServiceStatus().then((r) => r.data),
    refetchInterval: 30000,
  });

  const activeSignalsQuery = useQuery({
    queryKey: ['dashboard-active-signals'],
    queryFn: () => dashboardAPI.getActiveSignals().then((r) => r.data),
    refetchInterval: 15000,
  });

  const stats = statsQuery.data;

  const signalChart = Array.isArray(signalChartQuery.data) ? signalChartQuery.data : [];
  const signalChartEmpty = signalChart.every((d) => !d.signals && !d.wins);

  const userGrowth = Array.isArray(userGrowthQuery.data) ? userGrowthQuery.data : [];
  const userGrowthEmpty = userGrowth.every((d) => !d.users);

  const services = Array.isArray(servicesQuery.data) ? servicesQuery.data : [];
  const activeSignals = Array.isArray(activeSignalsQuery.data) ? activeSignalsQuery.data : [];

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-text-primary">داشبورد</h1>

      {/* ── کارت‌های آمار ── */}
      {statsQuery.isLoading ? (
        <CardSkeleton count={4} />
      ) : statsQuery.isError ? (
        <div className="card">
          <ErrorState
            description="دریافت آمار داشبورد ناموفق بود."
            onRetry={statsQuery.refetch}
            compact
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={Users}
            title="کل کاربران"
            value={toPersianDigits(formatNumber(stats?.totalUsers ?? 0))}
            variant="info"
          />
          <StatCard
            icon={Signal}
            title="سیگنال‌های امروز"
            value={toPersianDigits(formatNumber(stats?.signalsToday ?? 0))}
            variant="success"
          />
          <StatCard
            icon={TrendingUp}
            title="نرخ برد"
            value={`${toPersianDigits(stats?.winRate ?? 0)}٪`}
            variant="success"
          />
          <StatCard
            icon={DollarSign}
            title="سود کل (پیپ)"
            value={toPersianDigits(formatNumber(stats?.totalProfit ?? 0))}
            variant="info"
          />
        </div>
      )}

      {/* ── نمودارها ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* سیگنال‌ها vs برنده‌ها */}
        {signalChartQuery.isLoading ? (
          <ChartSkeleton height={280} />
        ) : (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">
              سیگنال‌ها - ۳۰ روز اخیر
            </h3>
            {signalChartQuery.isError ? (
              <ErrorState
                description="دریافت نمودار سیگنال‌ها ناموفق بود."
                onRetry={signalChartQuery.refetch}
                compact
              />
            ) : signalChartEmpty ? (
              <EmptyState
                icon={Signal}
                title="سیگنالی در این بازه ثبت نشده"
                description="با ثبت سیگنال‌ها، روند تعداد کل و سیگنال‌های برنده اینجا نمایش داده می‌شود."
                compact
              />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={signalChart}>
                  <defs>
                    <linearGradient id="signalGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2979FF" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#2979FF" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="winsGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00C853" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#00C853" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" />
                  <XAxis dataKey="date" tick={axisTick} axisLine={axisLine} tickFormatter={faTick} />
                  <YAxis tick={axisTick} axisLine={axisLine} tickFormatter={faTick} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="signals"
                    stroke="#2979FF"
                    fill="url(#signalGrad)"
                    strokeWidth={2}
                    name="کل سیگنال"
                  />
                  <Area
                    type="monotone"
                    dataKey="wins"
                    stroke="#00C853"
                    fill="url(#winsGrad)"
                    strokeWidth={2}
                    name="سیگنال برنده"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        )}

        {/* رشد کاربران */}
        {userGrowthQuery.isLoading ? (
          <ChartSkeleton height={280} />
        ) : (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">رشد کاربران</h3>
            {userGrowthQuery.isError ? (
              <ErrorState
                description="دریافت نمودار رشد کاربران ناموفق بود."
                onRetry={userGrowthQuery.refetch}
                compact
              />
            ) : userGrowthEmpty ? (
              <EmptyState
                icon={UserPlus}
                title="هنوز کاربری ثبت نشده"
                description="با عضویت کاربران، روند رشد در این نمودار نمایش داده می‌شود."
                compact
              />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={userGrowth}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" />
                  <XAxis dataKey="date" tick={axisTick} axisLine={axisLine} tickFormatter={faTick} />
                  <YAxis tick={axisTick} axisLine={axisLine} tickFormatter={faTick} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="users"
                    stroke="#2979FF"
                    strokeWidth={2}
                    dot={false}
                    name="کاربران"
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        )}
      </div>

      {/* ── سرویس‌ها و سیگنال‌های فعال ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* وضعیت سرویس‌ها */}
        <div className="card lg:col-span-1">
          <h3 className="text-sm font-semibold text-text-primary mb-4">وضعیت سرویس‌ها</h3>
          {servicesQuery.isLoading ? (
            <div className="space-y-3">
              <TableSkeleton columns={2} rows={5} />
            </div>
          ) : servicesQuery.isError ? (
            <ErrorState
              description="دریافت وضعیت سرویس‌ها ناموفق بود."
              onRetry={servicesQuery.refetch}
              compact
            />
          ) : services.length === 0 ? (
            <EmptyState
              icon={Server}
              title="سرویسی یافت نشد"
              description="اطلاعات وضعیت سرویس‌ها در دسترس نیست."
              compact
            />
          ) : (
            <div className="space-y-3">
              {services.map((svc, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between py-2 border-b border-surface-border last:border-0"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-2.5 h-2.5 rounded-full ${
                        svc.status === 'online'
                          ? 'bg-brand-green shadow-[0_0_6px_rgba(0,200,83,0.5)]'
                          : svc.status === 'warning'
                          ? 'bg-yellow-500 shadow-[0_0_6px_rgba(234,179,8,0.5)]'
                          : 'bg-brand-red shadow-[0_0_6px_rgba(255,23,68,0.5)]'
                      }`}
                    />
                    <span className="text-sm text-text-primary">{svc.name}</span>
                  </div>
                  <span className="text-xs text-text-muted">{toPersianDigits(svc.uptime)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* سیگنال‌های فعال */}
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-text-primary">سیگنال‌های فعال</h3>
            {!activeSignalsQuery.isLoading && !activeSignalsQuery.isError && (
              <div className="flex items-center gap-1.5">
                <Activity size={14} className="text-brand-green" />
                <span className="text-xs text-text-muted">
                  {toPersianDigits(activeSignals.length)} سیگنال فعال
                </span>
              </div>
            )}
          </div>

          {activeSignalsQuery.isLoading ? (
            <TableSkeleton columns={7} rows={5} />
          ) : activeSignalsQuery.isError ? (
            <ErrorState
              description="دریافت سیگنال‌های فعال ناموفق بود."
              onRetry={activeSignalsQuery.refetch}
              compact
            />
          ) : activeSignals.length === 0 ? (
            <EmptyState
              icon={BarChart3}
              title="سیگنال فعالی وجود ندارد"
              description="سیگنال‌های باز پس از ثبت، همراه با سود/ضرر لحظه‌ای اینجا نمایش داده می‌شوند."
              compact
            />
          ) : (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>نماد</th>
                    <th>نوع</th>
                    <th>ورود</th>
                    <th>TP</th>
                    <th>SL</th>
                    <th>سود/ضرر</th>
                    <th>زمان</th>
                  </tr>
                </thead>
                <tbody>
                  {activeSignals.map((sig) => (
                    <tr key={sig.id}>
                      <td className="font-medium text-text-primary">{sig.symbol}</td>
                      <td>
                        <span
                          className={`badge ${sig.type === 'BUY' ? 'badge-green' : 'badge-red'}`}
                        >
                          {sig.type === 'BUY' ? 'خرید' : 'فروش'}
                        </span>
                      </td>
                      <td className="font-mono text-xs">{toPersianDigits(sig.entry)}</td>
                      <td className="font-mono text-xs text-brand-green">
                        {toPersianDigits(sig.tp)}
                      </td>
                      <td className="font-mono text-xs text-brand-red">
                        {toPersianDigits(sig.sl)}
                      </td>
                      <td>
                        <span
                          className={`font-medium text-sm ${
                            sig.pnl >= 0 ? 'text-brand-green' : 'text-brand-red'
                          }`}
                        >
                          {sig.pnl >= 0 ? '+' : ''}
                          {toPersianDigits(sig.pnl)}
                        </span>
                      </td>
                      <td className="text-text-muted text-xs">{toPersianDigits(sig.time)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
