import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { performanceAPI } from '../api/client';
import {
  TrendingUp,
  Target,
  Award,
  BarChart3,
  Activity,
  Calendar,
  Grid3x3,
  LineChart as LineChartIcon,
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';
import { ChartSkeleton, CardSkeleton, TableSkeleton } from '../components/common/Skeleton';
import EmptyState from '../components/common/EmptyState';
import ErrorState from '../components/common/ErrorState';

function MetricCard({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="stat-card">
      <div className="flex items-center gap-2">
        <div
          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
            color === 'blue'
              ? 'bg-brand-blue/15 text-brand-blue'
              : color === 'green'
              ? 'bg-brand-green/15 text-brand-green'
              : 'bg-brand-red/15 text-brand-red'
          }`}
        >
          <Icon size={16} />
        </div>
        <span className="text-xs text-text-muted">{label}</span>
      </div>
      <p className="text-2xl font-bold text-text-primary mt-2">{value}</p>
      {sub && <p className="text-[11px] text-text-muted">{sub}</p>}
    </div>
  );
}

function HeatmapCell({ value }) {
  if (value === undefined || value === null) {
    return (
      <td className="px-3 py-2 text-center text-sm border-t border-surface-border">
        <span className="text-text-muted">—</span>
      </td>
    );
  }

  const getColor = (v) => {
    if (v >= 80) return 'bg-brand-green/30 text-brand-green';
    if (v >= 70) return 'bg-brand-green/15 text-brand-green';
    if (v >= 60) return 'bg-yellow-500/15 text-yellow-400';
    return 'bg-brand-red/15 text-brand-red';
  };

  return (
    <td className="px-3 py-2 text-center text-sm font-medium border-t border-surface-border">
      <span className={`inline-block px-2 py-1 rounded-md ${getColor(value)}`}>
        {toPersianDigits(value)}٪
      </span>
    </td>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-surface-elevated border border-surface-border rounded-lg px-3 py-2 shadow-xl text-xs">
      <p className="text-text-muted mb-1">{label}</p>
      {payload.map((entry, index) => (
        <p key={index} style={{ color: entry.color }} className="font-medium">
          {entry.name}:{' '}
          {typeof entry.value === 'number'
            ? toPersianDigits(entry.value.toFixed(1))
            : entry.value}
        </p>
      ))}
    </div>
  );
}

export default function PerformancePage() {
  const [period, setPeriod] = useState('30');

  const equityQuery = useQuery({
    queryKey: ['performance-equity', period],
    queryFn: () => performanceAPI.getEquityCurve({ days: period }).then((r) => r.data),
  });

  const winRateQuery = useQuery({
    queryKey: ['performance-winrate'],
    queryFn: () => performanceAPI.getWinRate({}).then((r) => r.data),
  });

  const heatmapQuery = useQuery({
    queryKey: ['performance-heatmap'],
    queryFn: () => performanceAPI.getHeatmap().then((r) => r.data),
  });

  const metricsQuery = useQuery({
    queryKey: ['performance-metrics'],
    queryFn: () => performanceAPI.getMetrics().then((r) => r.data),
  });

  const equity = Array.isArray(equityQuery.data) ? equityQuery.data : [];
  const winRate = winRateQuery.data || {};
  const bySymbol = Array.isArray(winRate.bySymbol) ? winRate.bySymbol : [];
  const byTimeframe = Array.isArray(winRate.byTimeframe) ? winRate.byTimeframe : [];
  const byDay = Array.isArray(winRate.byDay) ? winRate.byDay : [];
  const heatmap = Array.isArray(heatmapQuery.data) ? heatmapQuery.data : [];
  const metrics = metricsQuery.data;

  // ستون‌های نقشه‌ی حرارتی به‌صورت داینامیک از تایم‌فریم‌های موجود در داده ساخته می‌شوند
  const heatmapTimeframes = useMemo(() => {
    const set = new Set();
    heatmap.forEach((row) => {
      Object.keys(row).forEach((k) => {
        if (k !== 'symbol' && k !== 'total') set.add(k);
      });
    });
    return Array.from(set);
  }, [heatmap]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-text-primary">عملکرد</h1>
        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="text-sm min-w-[120px]"
        >
          <option value="7">۷ روز</option>
          <option value="30">۳۰ روز</option>
          <option value="90">۹۰ روز</option>
          <option value="365">۱ سال</option>
        </select>
      </div>

      {/* ── شاخص‌های کلیدی ── */}
      {metricsQuery.isLoading ? (
        <CardSkeleton count={4} />
      ) : metricsQuery.isError ? (
        <div className="card">
          <ErrorState
            description="دریافت شاخص‌های عملکرد ناموفق بود."
            onRetry={metricsQuery.refetch}
            compact
          />
        </div>
      ) : !metrics || metrics.totalTrades === 0 ? (
        <div className="card">
          <EmptyState
            icon={Activity}
            title="هنوز معامله‌ی بسته‌شده‌ای وجود ندارد"
            description="شاخص‌های عملکرد پس از بسته‌شدن اولین سیگنال‌ها (رسیدن به حد سود یا ضرر) محاسبه و نمایش داده می‌شوند."
          />
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            icon={TrendingUp}
            label="ضریب سود"
            value={toPersianDigits(metrics.profitFactor)}
            sub="Profit Factor"
            color="green"
          />
          <MetricCard
            icon={Award}
            label="نسبت شارپ"
            value={toPersianDigits(metrics.sharpeRatio)}
            sub="Sharpe Ratio"
            color="blue"
          />
          <MetricCard
            icon={BarChart3}
            label="حداکثر افت"
            value={`${toPersianDigits(metrics.maxDrawdown)}٪`}
            sub="Max Drawdown"
            color="red"
          />
          <MetricCard
            icon={Target}
            label="کل معاملات"
            value={toPersianDigits(metrics.totalTrades)}
            sub={`میانگین برد: ${toPersianDigits(metrics.avgWin)} | میانگین باخت: ${toPersianDigits(metrics.avgLoss)}`}
            color="blue"
          />
        </div>
      )}

      {/* ── منحنی سرمایه ── */}
      {equityQuery.isLoading ? (
        <ChartSkeleton height={320} />
      ) : (
        <div className="card">
          <h3 className="text-sm font-semibold text-text-primary mb-4">منحنی سرمایه</h3>
          {equityQuery.isError ? (
            <ErrorState
              description="دریافت منحنی سرمایه ناموفق بود."
              onRetry={equityQuery.refetch}
              compact
            />
          ) : equity.length === 0 ? (
            <EmptyState
              icon={LineChartIcon}
              title="داده‌ای برای منحنی سرمایه نیست"
              description="با بسته‌شدن معاملات در بازه‌ی انتخاب‌شده، روند سرمایه اینجا رسم می‌شود."
              compact
            />
          ) : (
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={equity}>
                <defs>
                  <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00C853" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#00C853" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" />
                <XAxis
                  dataKey="date"
                  tick={{ fill: '#636882', fontSize: 10 }}
                  axisLine={{ stroke: '#2a2e3d' }}
                />
                <YAxis tick={{ fill: '#636882', fontSize: 10 }} axisLine={{ stroke: '#2a2e3d' }} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="equity"
                  stroke="#00C853"
                  strokeWidth={2}
                  dot={false}
                  name="سرمایه ($)"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      )}

      {/* ── نرخ برد بر اساس نماد / تایم‌فریم ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {winRateQuery.isLoading ? (
          <ChartSkeleton height={280} />
        ) : (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">نرخ برد بر اساس نماد</h3>
            {winRateQuery.isError ? (
              <ErrorState
                description="دریافت آمار نرخ برد ناموفق بود."
                onRetry={winRateQuery.refetch}
                compact
              />
            ) : bySymbol.length === 0 ? (
              <EmptyState
                icon={BarChart3}
                title="داده‌ای بر اساس نماد نیست"
                description="پس از بسته‌شدن معاملات، نرخ برد هر نماد اینجا نمایش داده می‌شود."
                compact
              />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={bySymbol} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" horizontal={false} />
                  <XAxis
                    type="number"
                    domain={[0, 100]}
                    tick={{ fill: '#636882', fontSize: 10 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    tick={{ fill: '#9499ae', fontSize: 11 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                    width={70}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="winRate" name="نرخ برد (٪)" radius={[0, 4, 4, 0]} barSize={18}>
                    {bySymbol.map((entry, index) => (
                      <Cell
                        key={index}
                        fill={
                          entry.winRate >= 70
                            ? '#00C853'
                            : entry.winRate >= 60
                            ? '#FFC107'
                            : '#FF1744'
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        )}

        {winRateQuery.isLoading ? (
          <ChartSkeleton height={280} />
        ) : (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">
              نرخ برد بر اساس تایم‌فریم
            </h3>
            {winRateQuery.isError ? (
              <ErrorState
                description="دریافت آمار نرخ برد ناموفق بود."
                onRetry={winRateQuery.refetch}
                compact
              />
            ) : byTimeframe.length === 0 ? (
              <EmptyState
                icon={BarChart3}
                title="داده‌ای بر اساس تایم‌فریم نیست"
                description="پس از بسته‌شدن معاملات، نرخ برد هر تایم‌فریم اینجا نمایش داده می‌شود."
                compact
              />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={byTimeframe}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#9499ae', fontSize: 11 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fill: '#636882', fontSize: 10 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar
                    dataKey="winRate"
                    name="نرخ برد (٪)"
                    fill="#2979FF"
                    radius={[4, 4, 0, 0]}
                    barSize={32}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        )}
      </div>

      {/* ── نرخ برد بر اساس روز هفته / نقشه‌ی حرارتی ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {winRateQuery.isLoading ? (
          <ChartSkeleton height={280} />
        ) : (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">
              نرخ برد بر اساس روز هفته
            </h3>
            {winRateQuery.isError ? (
              <ErrorState
                description="دریافت آمار نرخ برد ناموفق بود."
                onRetry={winRateQuery.refetch}
                compact
              />
            ) : byDay.length === 0 ? (
              <EmptyState
                icon={Calendar}
                title="داده‌ای بر اساس روز هفته نیست"
                description="پس از بسته‌شدن معاملات، نرخ برد هر روز هفته اینجا نمایش داده می‌شود."
                compact
              />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={byDay}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2e3d" />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#9499ae', fontSize: 10 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fill: '#636882', fontSize: 10 }}
                    axisLine={{ stroke: '#2a2e3d' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="winRate" name="نرخ برد (٪)" radius={[4, 4, 0, 0]} barSize={28}>
                    {byDay.map((entry, index) => (
                      <Cell
                        key={index}
                        fill={
                          entry.winRate >= 73
                            ? '#00C853'
                            : entry.winRate >= 68
                            ? '#2979FF'
                            : '#FF1744'
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        )}

        <div className="card">
          <h3 className="text-sm font-semibold text-text-primary mb-4">نقشه حرارتی نرخ برد</h3>
          {heatmapQuery.isLoading ? (
            <TableSkeleton columns={4} rows={5} />
          ) : heatmapQuery.isError ? (
            <ErrorState
              description="دریافت نقشه‌ی حرارتی ناموفق بود."
              onRetry={heatmapQuery.refetch}
              compact
            />
          ) : heatmap.length === 0 || heatmapTimeframes.length === 0 ? (
            <EmptyState
              icon={Grid3x3}
              title="داده‌ای برای نقشه‌ی حرارتی نیست"
              description="با بسته‌شدن معاملات در نمادها و تایم‌فریم‌های مختلف، نقشه‌ی حرارتی نرخ برد ساخته می‌شود."
              compact
            />
          ) : (
            <>
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>نماد</th>
                      {heatmapTimeframes.map((tf) => (
                        <th key={tf} className="text-center">
                          {tf}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {heatmap.map((row, idx) => (
                      <tr key={idx}>
                        <td className="font-medium text-text-primary text-sm">{row.symbol}</td>
                        {heatmapTimeframes.map((tf) => (
                          <HeatmapCell key={tf} value={row[tf]} />
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex items-center justify-center gap-4 mt-4 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-brand-red/30" />
                  <span className="text-text-muted">کمتر از ۶۰٪</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-yellow-500/30" />
                  <span className="text-text-muted">۶۰-۷۰٪</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-brand-green/20" />
                  <span className="text-text-muted">۷۰-۸۰٪</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-brand-green/40" />
                  <span className="text-text-muted">بیشتر از ۸۰٪</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── آمار تکمیلی ── */}
      {metricsQuery.isLoading ? (
        <ChartSkeleton height={90} />
      ) : (
        !metricsQuery.isError &&
        metrics &&
        metrics.totalTrades > 0 && (
          <div className="card">
            <h3 className="text-sm font-semibold text-text-primary mb-4">آمار تکمیلی</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <StatItem
                label="میانگین سود (پیپ)"
                value={toPersianDigits(metrics.avgWin)}
                color="green"
              />
              <StatItem
                label="میانگین ضرر (پیپ)"
                value={toPersianDigits(metrics.avgLoss)}
                color="red"
              />
              <StatItem
                label="بیشترین بردهای متوالی"
                value={toPersianDigits(metrics.consecutiveWins)}
                color="blue"
              />
              <StatItem
                label="بیشترین باخت‌های متوالی"
                value={toPersianDigits(metrics.consecutiveLosses)}
                color="red"
              />
            </div>
          </div>
        )
      )}
    </div>
  );
}

function StatItem({ label, value, color }) {
  const colorClass =
    color === 'green'
      ? 'text-brand-green'
      : color === 'red'
      ? 'text-brand-red'
      : 'text-brand-blue';

  return (
    <div className="bg-surface-elevated rounded-lg p-3">
      <p className="text-[11px] text-text-muted mb-1">{label}</p>
      <p className={`text-lg font-bold ${colorClass}`}>{value}</p>
    </div>
  );
}
